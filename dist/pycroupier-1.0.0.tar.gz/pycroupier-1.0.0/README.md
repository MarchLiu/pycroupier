# Croupier

Croupier library support rand select items from list with difference algo.

## Installation

```
pip install pycrouiper
```

## Usage

Just like this:

```
>>> import croupier
>>> damping = croupier.damping()
>>> data = ["b", "e", "h", "d", "f"]
>>> damping.draw(data, 2)

```
